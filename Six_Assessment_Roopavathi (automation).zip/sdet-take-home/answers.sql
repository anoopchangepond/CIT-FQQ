-- Task 1: Price Changes
-- Create yesterday's products table
CREATE TABLE products_yesterday (
    product_id INT,
    product_name VARCHAR(100),
    price DECIMAL(10,2),
    status VARCHAR(20)
);

-- Create today's products table
CREATE TABLE products_today (
    product_id INT,
    product_name VARCHAR(100),
    price DECIMAL(10,2),
    status VARCHAR(20)
);

-- Insert yesterday's data
INSERT INTO products_yesterday (product_id, product_name, price, status) VALUES
(1001, 'Coffee Mug', 12.50, 'ACTIVE'),
(1002, 'Laptop Stand', 38.00, 'ACTIVE'),
(1003, 'Wireless Mouse', 19.99, 'ACTIVE'),
(1004, 'Old Keyboard', 29.99, 'DISCONTINUED'),
(1005, 'Notebook', 4.50, 'ACTIVE'),
(1008, 'Desk Lamp', 24.00, 'ACTIVE');

-- Insert today's data
INSERT INTO products_today (product_id, product_name, price, status) VALUES
(1001, 'Coffee Mug', 12.50, 'ACTIVE'),
(1002, 'Laptop Stand', 35.00, 'ACTIVE'),
(1003, 'Wireless Mouse', 21.99, 'ACTIVE'),
(1005, 'Notebook', 4.50, 'ACTIVE'),
(1006, 'Webcam', 59.00, 'ACTIVE'),
(1007, 'USB Cable', 7.99, 'ACTIVE'),
(1008, 'Desk Lamp', 24.00, 'DISCONTINUED');

-- Find products whose price changed
SELECT
    y.product_id,
    y.product_name,
    y.price AS old_price,
    t.price AS new_price
FROM products_yesterday y
JOIN products_today t
    ON y.product_id = t.product_id
WHERE y.price <> t.price;
-- Task 2: New Products
SELECT t.product_id, t.product_name, t.price, t.status
FROM products_today t
LEFT JOIN products_yesterday y ON t.product_id = y.product_id
WHERE y.product_id IS NULL;

-- Task 3: Missing Products
SELECT y.product_id, y.product_name, y.price, y.status
FROM products_yesterday y
LEFT JOIN products_today t ON y.product_id = t.product_id
WHERE t.product_id IS NULL;

-- Task 4: Status Changes
SELECT t.product_id, t.product_name, y.status AS old_status, t.status AS new_status
FROM products_today t
JOIN products_yesterday y ON t.product_id = y.product_id
WHERE t.status <> y.status;

SQL Task 5 — Short Explanation
In your README, briefly explain:
1.	Why did you use INNER JOIN, LEFT JOIN, NOT EXISTS, or another approach?
I used INNER JOIN when comparing products that exist in both yesterday's and today's tables, such as price changes and status changes. INNER JOIN returns only products that have a matching product_id in both tables.
I used LEFT JOIN for finding new products and missing products.
•	For new products, I started with products_today and used LEFT JOIN with products_yesterday. Then I used WHERE y.product_id IS NULL to find products that did not  match or exist yesterday.
•	For missing products, I started with products_yesterday and used LEFT JOIN with products_today. Then I used WHERE t.product_id IS NULL to find products that no longer exist today.

2.	What would change if product_id was not unique?
If product_id was not unique, a JOIN could produce multiple rows for the same product because one product could match multiple records in the other table.
For example, if product 1001 appeared twice yesterday and twice today, the JOIN could produce multiple combinations of those records.
Therefore, product_id should ideally be unique in both tables. If it is not unique, we would first need to decide how to identify the correct record, possibly by using another column, a composite key, or aggregation.

3.	What issue could happen if price or status can be NULL?
If price or status is NULL, using <> may not detect changes correctly because NULL represents an unknown value. We should handle NULL separately or use a NULL-safe comparison.
If price or status can be NULL, use a NULL-safe comparison.
WHERE t.price IS DISTINCT FROM y.price;
For status:
WHERE t.status IS DISTINCT FROM y.status;
This correctly identifies changes such as:
NULL → 20.00     = Changed
20.00 → NULL     = Changed
NULL → NULL      = No change
20.00 → 30.00    = Changed


