const { defineConfig } = require("@playwright/test");

module.exports = defineConfig({
  testDir: ".",
  testMatch: "**/*.test.js",
  use: {
    baseURL: process.env.API_BASE_URL || "http://localhost:3000"
  }
});