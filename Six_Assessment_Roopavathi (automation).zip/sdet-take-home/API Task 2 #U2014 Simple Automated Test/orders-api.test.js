const { test, expect } = require("@playwright/test");

// Mock origin used purely as a stable URL to attach route interception to.
// No real network call is ever made: page.route() intercepts every request
// to this origin (including the document navigation) and fulfills it
// locally, so the "server" here is entirely simulated by Playwright.
const BASE = "https://api.example.test";

/**
 * Registers a route handler that intercepts calls to `path` under BASE and
 * fulfills them with `mockResponse`, then navigates the page to BASE so the
 * page has a same-origin context to issue fetch() calls from.
 */
async function mockOrdersApi(page, path, mockResponse) {
  await page.route(`${BASE}/**`, async (route) => {
    const url = new URL(route.request().url());

    if (url.pathname === "/") {
      // Minimal document so page.goto() can complete without touching the
      // real network.
      await route.fulfill({ status: 200, contentType: "text/html", body: "<html></html>" });
      return;
    }

    if (url.pathname === path) {
      await route.fulfill({
        status: mockResponse.status,
        contentType: "application/json",
        body: JSON.stringify(mockResponse.body)
      });
      return;
    }

    await route.continue();
  });

  await page.goto(`${BASE}/`);
}

async function fetchJson(page, path) {
  return page.evaluate(async ({ base, path }) => {
    const res = await fetch(base + path);
    let body = null;
    try {
      body = await res.json();
    } catch (error) {
      body = null;
    }
    return { status: res.status, body };
  }, { base: BASE, path });
}

test("GET /api/orders/{order_id} returns 200 and status PAID for a valid order", async ({ page }) => {
  await mockOrdersApi(page, "/api/orders/ORD-1001", {
    status: 200,
    body: {
      order_id: "ORD-1001",
      customer_id: "C001",
      amount: 100.5,
      currency: "GBP",
      status: "PAID",
      created_at: "2026-05-20T10:30:00Z"
    }
  });

  const result = await fetchJson(page, "/api/orders/ORD-1001");

  expect(result.status).toBe(200);
  expect(result.body.order_id).toBe("ORD-1001");
  expect(result.body.status).toBe("PAID");
});

test("GET /api/orders/{order_id} returns 404 for a non-existent order", async ({ page }) => {
  await mockOrdersApi(page, "/api/orders/ORD-9999", {
    status: 404,
    body: { error: "Order not found" }
  });

  const result = await fetchJson(page, "/api/orders/ORD-9999");

  expect(result.status).toBe(404);
});
