# SDET Take-Home Exercise

## 1. Language Used

Java.

The CSV comparison tool uses standard Java libraries. The test file is written for JUnit 5.

## 2. How to Run the CSV Comparison Tool

Compile:

```bash
javac -d . headercomparison/CompareHeaders.java
```

Run:

```bash
java headercomparison.CompareHeaders expected_orders.csv actual_orders.csv
```

The program reports headers only in the expected file, headers only in the actual file, common headers, and whether common headers are in the same relative order.

## 3. Error-Handling Program

`Error Handling/CompareHeaders.java` is the Java implementation for Coding
Task 3. It reports clear errors and exits with code `1` when an argument is
missing, a file does not exist, a CSV file is empty, or its header row contains
no valid headers.

From the `Error Handling` directory, run:

```bash
javac CompareHeaders.java
java CompareHeaders expected.csv actual.csv
```

## 4. How to Run the Tests

`Error Handling/CompareHeaders.java` includes a self-test harness (`--self-test`)
that calls the same production `run()` method used by `main()` — it is not a
separate re-implementation. The harness covers:

- The 5 required Coding Task 2 scenarios, each as its own assertion: identical
  headers, a missing header, headers with extra spaces, Windows (`\r\n`) line
  endings, and headers in a different order.
- All 4 required error-handling scenarios: missing argument, file not found,
  empty file, and a header row with no valid headers.

It uses only the Java standard library, so no external test dependency is
required.

From the `Error Handling` directory:

```bash
javac CompareHeaders.java
java CompareHeaders --self-test
```

## 5. SQL Answers

The SQL answers are provided in `answers.sql`.

## 6. API Test Cases

For `GET /api/orders/{order_id}`:

| Test | Expected result |
|---|---|
| Valid order ID `ORD-1001` | HTTP 200 and `status = PAID` |
| Non-existent order ID | HTTP 404 |
| Invalid/malformed order ID | HTTP 400 or documented validation response |
| Missing/empty order ID | HTTP 400 or documented client error |
| Unauthorized request | HTTP 401/403 when authentication is required |

`API Task 2 — Simple Automated Test/orders-api.test.js` automates the first
two rows above. It uses Playwright's `page.route()` to intercept the HTTP
request and fulfill it with a mocked response, so the assertions run against
a real (mocked) response object returned from `fetch()` rather than a
hardcoded literal. From that directory:

```bash
npm install
npx playwright test
```

## 7. Assumptions

- Each CSV contains a header row as its first row.
- The CSV input is intentionally simple as specified by the exercise; a heavy CSV library is not required.
- Header whitespace is trimmed before comparison.
- Header names are case-sensitive.
- `product_id` is expected to be unique in each SQL table.
- If SQL `price` or `status` can be NULL, a NULL-safe comparison should be used where supported by the target database.
- The exercise contains two versions of `actual_orders.csv`. This submission uses the first explicit coding-task version with `total_amount`, `processed_at`, and `country_code`.

## 8. AI Usage Statement

I used ChatGPT during the take-home exercise to help understand the requirements, consider implementation and testing approaches, identify edge cases, and prepare documentation.

I reviewed the suggestions and made the final implementation decisions myself. I understand the submitted solution and can explain, modify, test, and debug it during the interview.

The relevant AI usage record is included in `AI_TRANSCRIPT.md`.

## 9. Candidate Acknowledgement

By submitting this exercise, I confirm that:

1. I have followed the AI usage rules.
2. If I used AI, I have included the full relevant AI transcript or equivalent usage record.
3. I understand the submitted solution.
4. I am able to explain, modify, and debug the solution during the interview.
5. I understand that failure to disclose AI use, or inability to explain the submitted work, may result in rejection.
