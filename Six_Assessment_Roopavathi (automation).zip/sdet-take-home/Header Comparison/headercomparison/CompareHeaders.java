package headercomparison;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class CompareHeaders {
    public static void main(String[] args) {
        if (args.length != 2) {
            System.err.println("Usage: java headercomparison.CompareHeaders <expected.csv> <actual.csv>");
            System.exit(1);
        }

        try {
            List<String> expectedHeaders = readHeaders(Paths.get(args[0]));
            List<String> actualHeaders = readHeaders(Paths.get(args[1]));

            Set<String> expectedSet = new HashSet<>(expectedHeaders);
            Set<String> actualSet = new HashSet<>(actualHeaders);

            List<String> onlyInExpected = new ArrayList<>(expectedHeaders);
            onlyInExpected.removeIf(actualSet::contains);

            List<String> onlyInActual = new ArrayList<>(actualHeaders);
            onlyInActual.removeIf(expectedSet::contains);

            List<String> commonHeaders = new ArrayList<>();
            for (String header : expectedHeaders) {
                if (actualSet.contains(header)) {
                    commonHeaders.add(header);
                }
            }

            System.out.println("Only in " + Paths.get(args[0]).getFileName() + ":");
            printHeaders(onlyInExpected);
            System.out.println();

            System.out.println("Only in " + Paths.get(args[1]).getFileName() + ":");
            printHeaders(onlyInActual);
            System.out.println();

            System.out.println("Common headers:");
            printHeaders(commonHeaders);
            System.out.println();

            System.out.println("Common headers in same relative order:");
            System.out.println(hasSameRelativeOrder(expectedHeaders, actualHeaders));
        } catch (IOException | IllegalArgumentException exception) {
            System.err.println("Error: " + exception.getMessage());
            System.exit(1);
        }
    }

    private static List<String> readHeaders(Path file) throws IOException {
        try (BufferedReader reader = Files.newBufferedReader(file)) {
            String firstRow = reader.readLine();
            if (firstRow == null) {
                throw new IllegalArgumentException("File is empty: " + file);
            }

            List<String> headers = new ArrayList<>();
            for (String header : firstRow.split(",", -1)) {
                String trimmedHeader = header.trim();
                if (!trimmedHeader.isEmpty()) {
                    headers.add(trimmedHeader);
                }
            }

            if (headers.isEmpty()) {
                throw new IllegalArgumentException("Header row contains no valid headers: " + file);
            }
            return headers;
        }
    }

    private static void printHeaders(List<String> headers) {
        for (String header : headers) {
            System.out.println(header);
        }
    }

    private static boolean hasSameRelativeOrder(List<String> expectedHeaders, List<String> actualHeaders) {
        List<String> commonInExpectedOrder = new ArrayList<>();
        for (String header : expectedHeaders) {
            if (actualHeaders.contains(header)) {
                commonInExpectedOrder.add(header);
            }
        }

        List<String> commonInActualOrder = new ArrayList<>();
        for (String header : actualHeaders) {
            if (expectedHeaders.contains(header)) {
                commonInActualOrder.add(header);
            }
        }

        return commonInExpectedOrder.equals(commonInActualOrder);
    }
}
