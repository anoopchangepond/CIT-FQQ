# AI Transcript

## 1. AI Tool Used

ChatGPT.

## 2. Relevant Prompts and Responses

### Prompt 1

**Prompt entered:**

Create a short README.md containing:
1. Language used.
2. How to run the CSV comparison tool.
3. How to run the tests.
4. SQL answers.
5. API test cases.
6. Any assumptions you made.
7. AI usage statement.

**AI response relied upon:**

ChatGPT provided a README template with sections for language, run instructions, tests, SQL answers, API test cases, assumptions, and AI usage.

### Prompt 2

**Prompt entered:**

I provided the exercise AI Usage Policy and asked how to document AI usage, including how AI was used, prompts used, what AI got right or wrong, what I changed, and why the final solution works.

**AI response relied upon:**

ChatGPT explained that the relevant AI conversation must be disclosed and that a short summary is not enough. It also helped structure the required disclosure sections.

### Prompt 3

**Prompt entered:**

I provided the candidate deliverables and Java structure and asked how the submission should be organized.

**AI response relied upon:**

ChatGPT recommended a simple Java submission containing README.md, AI_TRANSCRIPT.md, answers.sql, the two CSV files, CompareHeaders.java, and CompareHeadersTest.java.

### Prompt 4

**Prompt entered:**

I provided the complete take-home exercise, including SQL, CSV comparison, API testing, README, AI policy, and deliverables, and asked for a submission based on it.

**AI response relied upon:**

ChatGPT reviewed the requirements and highlighted implementation considerations, including SQL JOIN choices, CSV header comparison requirements, error handling, API test cases, and required deliverables.

## 3. Follow-up / Improvement

The AI suggestions were used to refine the structure and identify edge cases. The final implementation was adapted to the exact requirements of the exercise, including two CSV path arguments, trimmed headers, expected-only/actual-only/common headers, relative-order checking, and basic error handling.

## 4. What I Changed Myself

The AI-generated material was treated as guidance rather than a final implementation. I reviewed the requirements and made the final project-specific decisions myself.

I also identified that the exercise contains two different examples of `actual_orders.csv`. I selected the first explicit coding-task version and documented this assumption in the README.

I changed the API test examples to fit the GET endpoint rather than using a duplicate/idempotency scenario that would be more appropriate for a POST operation.

## 5. Final Responsibility

I understand the submitted code, SQL, tests, and documentation and am responsible for the final solution. I can explain, modify, test, and debug the solution during the interview.
