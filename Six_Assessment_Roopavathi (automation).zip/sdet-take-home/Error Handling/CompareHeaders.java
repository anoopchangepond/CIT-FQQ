import java.io.ByteArrayOutputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class CompareHeaders {

    public static void main(String[] args) {
        if (args.length == 1 && "--self-test".equals(args[0])) {
            System.exit(runSelfTests(System.out, System.err));
        }
        System.exit(run(args, System.out, System.err));
    }

    static int run(String[] args, PrintStream out, PrintStream err) {
        if (args.length != 2) {
            err.println("Usage: java CompareHeaders expected.csv actual.csv");
            return 1;
        }

        try {
            List<String> expected = getHeaders(Paths.get(args[0]));
            List<String> actual = getHeaders(Paths.get(args[1]));
            printComparison(expected, actual, out);
            return 0;
        } catch (IOException | IllegalArgumentException exception) {
            err.println("Error: " + exception.getMessage());
            return 1;
        }
    }

    private static List<String> getHeaders(Path file) throws IOException {
        if (!Files.exists(file)) {
            throw new IllegalArgumentException(file + " not found");
        }

        if (!Files.isRegularFile(file)) {
            throw new IllegalArgumentException(file + " is not a file");
        }

        try (BufferedReader reader = Files.newBufferedReader(file)) {
            String firstLine = reader.readLine();
            if (firstLine == null) {
                throw new IllegalArgumentException(file + " is empty");
            }

            List<String> headers = new ArrayList<>();
            for (String header : firstLine.split(",", -1)) {
                String trimmedHeader = header.trim();
                if (!trimmedHeader.isEmpty()) {
                    headers.add(trimmedHeader);
                }
            }

            if (headers.isEmpty()) {
                throw new IllegalArgumentException("No valid headers in " + file);
            }
            return headers;
        }
    }

    private static void printComparison(List<String> expected, List<String> actual, PrintStream out) {
        List<String> onlyExpected = new ArrayList<>();
        for (String header : expected) {
            if (!actual.contains(header)) {
                onlyExpected.add(header);
            }
        }

        List<String> onlyActual = new ArrayList<>();
        for (String header : actual) {
            if (!expected.contains(header)) {
                onlyActual.add(header);
            }
        }

        List<String> common = new ArrayList<>();
        for (String header : expected) {
            if (actual.contains(header)) {
                common.add(header);
            }
        }

        List<String> actualCommon = new ArrayList<>();
        for (String header : actual) {
            if (expected.contains(header)) {
                actualCommon.add(header);
            }
        }

        out.println("Only in expected file:");
        printHeaders(onlyExpected, out);
        out.println("\nOnly in actual file:");
        printHeaders(onlyActual, out);
        out.println("\nCommon headers:");
        printHeaders(common, out);
        out.println("\nCommon headers in same relative order:");
        out.println(common.equals(actualCommon));
    }

    private static void printHeaders(List<String> headers, PrintStream out) {
        for (String header : headers) {
            out.println(header);
        }
    }

    private static int runSelfTests(PrintStream out, PrintStream err) {
        Path directory = null;
        try {
            directory = Files.createTempDirectory("compare-headers-test-");

            // --- Coding Task 2: 5 required header-comparison scenarios ---
            // Each calls the same production run() method used by main(), so these
            // assertions exercise the real comparison logic rather than a re-implementation.

            // 1. Identical headers
            Path identicalA = write(directory, "identical_a.csv", "Name,Age,City\nJohn,20,Chennai\n");
            Path identicalB = write(directory, "identical_b.csv", "Name,Age,City\nAlice,25,Mumbai\n");
            assertResult(
                new String[] {identicalA.toString(), identicalB.toString()},
                0,
                "Common headers:\nName\nAge\nCity",
                "Common headers in same relative order:\ntrue"
            );

            // 2. One header is missing
            Path missingA = write(directory, "missing_a.csv", "Name,Age,City\nJohn,20,Chennai\n");
            Path missingB = write(directory, "missing_b.csv", "Name,Age\nAlice,25\n");
            assertResult(
                new String[] {missingA.toString(), missingB.toString()},
                0,
                "Only in expected file:\nCity"
            );

            // 3. Headers contain extra spaces
            Path spacesA = write(directory, "spaces_a.csv", "Name, Age, City\nJohn,20,Chennai\n");
            Path spacesB = write(directory, "spaces_b.csv", "Name,Age,City\nAlice,25,Mumbai\n");
            assertResult(
                new String[] {spacesA.toString(), spacesB.toString()},
                0,
                "Common headers:\nName\nAge\nCity",
                "Common headers in same relative order:\ntrue"
            );

            // 4. Windows line endings (\r\n)
            Path crlfA = write(directory, "crlf_a.csv", "Name,Age,City\r\nJohn,20,Chennai\r\n");
            Path crlfB = write(directory, "crlf_b.csv", "Name,Age,City\r\nAlice,25,Mumbai\r\n");
            assertResult(
                new String[] {crlfA.toString(), crlfB.toString()},
                0,
                "Common headers:\nName\nAge\nCity",
                "Common headers in same relative order:\ntrue"
            );

            // 5. Headers are in a different order
            Path orderA = write(directory, "order_a.csv", "Name,Age,City\nJohn,20,Chennai\n");
            Path orderB = write(directory, "order_b.csv", "City,Name,Age\nMumbai,Alice,25\n");
            assertResult(
                new String[] {orderA.toString(), orderB.toString()},
                0,
                "Common headers in same relative order:\nfalse"
            );

            // --- Error Handling: 4 required error scenarios ---
            Path expected = write(directory, "expected.csv", "order_id,status,created_at\n");
            Path actual = write(directory, "actual.csv", "order_id,status,processed_at\n");
            Path empty = write(directory, "empty.csv", "");
            Path invalid = write(directory, "invalid.csv", ", ,\n");

            assertResult(new String[] {expected.toString(), actual.toString()}, 0, "created_at", "processed_at");
            assertResult(new String[] {}, 1, "Usage: java CompareHeaders expected.csv actual.csv");
            assertResult(new String[] {directory.resolve("missing.csv").toString(), actual.toString()}, 1, "not found");
            assertResult(new String[] {empty.toString(), actual.toString()}, 1, "is empty");
            assertResult(new String[] {invalid.toString(), actual.toString()}, 1, "No valid headers");

            out.println("All CompareHeaders tests passed (5 Coding Task 2 scenarios + 4 error-handling scenarios).");
            return 0;
        } catch (Exception exception) {
            err.println("Self-test failed: " + exception.getMessage());
            return 1;
        } finally {
            if (directory != null) {
                try (Stream<Path> paths = Files.walk(directory)) {
                    paths.sorted((first, second) -> second.compareTo(first))
                        .forEach(path -> {
                            try {
                                Files.deleteIfExists(path);
                            } catch (IOException exception) {
                                throw new RuntimeException(exception);
                            }
                        });
                } catch (IOException exception) {
                    err.println("Warning: could not remove temporary test files: " + exception.getMessage());
                }
            }
        }
    }

    private static Path write(Path directory, String fileName, String contents) throws IOException {
        return Files.write(directory.resolve(fileName), contents.getBytes(StandardCharsets.UTF_8));
    }

    private static void assertResult(String[] arguments, int expectedExitCode, String... expectedText) {
        ByteArrayOutputStream standardOutput = new ByteArrayOutputStream();
        ByteArrayOutputStream standardError = new ByteArrayOutputStream();
        int actualExitCode = run(
            arguments,
            new PrintStream(standardOutput),
            new PrintStream(standardError)
        );

        if (actualExitCode != expectedExitCode) {
            throw new AssertionError("Expected exit code " + expectedExitCode + " but got " + actualExitCode);
        }

        String output = standardOutput.toString() + standardError.toString();
        for (String text : expectedText) {
            if (!output.contains(text)) {
                throw new AssertionError("Expected output to contain: " + text + "\nActual output:\n" + output);
            }
        }
    }
}
