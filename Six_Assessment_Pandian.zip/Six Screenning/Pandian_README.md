**AI used : Microsoft copilot**



**Prompt used:**

You are an SQl expert and need to generate the sql queries using the given tables

You are given two tables representing yesterday’s and today’s product data.

Table: products\_yesterday

product\_id	product\_name	price	status

1001	Coffee Mug	12.50	ACTIVE

1002	Laptop Stand	38.00	ACTIVE

1003	Wireless Mouse	19.99	ACTIVE

1004	Old Keyboard	29.99	DISCONTINUED

1005	Notebook	4.50	ACTIVE

1008	Desk Lamp	24.00	ACTIVE

Table: products\_today

product\_id	product\_name	price	status

1001	Coffee Mug	12.50	ACTIVE

1002	Laptop Stand	35.00	ACTIVE

1003	Wireless Mouse	21.99	ACTIVE

1005	Notebook	4.50	INACTIVE

1006	Webcam	59.00	ACTIVE

1007	USB Cable	7.99	ACTIVE

1008	Desk Lamp	24.00	ACTIVE



**PART - A**



**1. SQL Task 1 — Price Changes**



**Write a SQL query to find products whose price changed from yesterday to today.**

**Expected output columns:**

**product\_id, product\_name, old\_price, new\_price**



Query :



SELECT

&#x20;   p\_y.product\_id,

&#x20;   p\_y.product\_name,

&#x20;   p\_y.price AS old\_price,

&#x20;   p\_t.price AS new\_price

FROM

&#x20;   products\_yesterday p\_y

JOIN

&#x20;   products\_today p\_t

ON

&#x20;   p\_y.product\_id = p\_t.product\_id

WHERE

&#x20;   p\_y.price <> p\_t.price;



**2. SQL Task 2 — New Products**



**Write a SQL query to find products that are new today, meaning they exist in products\_today but not in products\_yesterday.**

**Expected output columns:**

**product\_id, product\_name, price, status**



Query:



SELECT

&#x20;   p\_t.product\_id,

&#x20;   p\_t.product\_name,

&#x20;   p\_t.price,

&#x20;   p\_t.status

FROM

&#x20;   products\_today p\_t

LEFT JOIN

&#x20;   products\_yesterday p\_y

ON

&#x20;   p\_t.product\_id = p\_y.product\_id

WHERE

&#x20;   p\_y.product\_id IS NULL;



**3. SQL Task 3 — Missing Products**



**Write a SQL query to find products that existed yesterday but are missing today.**

**Expected output columns:**

**product\_id, product\_name, price, status**



Query:



SELECT

&#x20;   p\_y.product\_id,

&#x20;   p\_y.product\_name,

&#x20;   p\_y.price,

&#x20;   p\_y.status

FROM

&#x20;   products\_yesterday p\_y

LEFT JOIN

&#x20;   products\_today p\_t

ON

&#x20;   p\_y.product\_id = p\_t.product\_id

WHERE

&#x20;   p\_t.product\_id IS NULL;



**4. SQL Task 4 — Status Changes**



**Write a SQL query to find products whose status changed from yesterday to today.**

**Expected output columns:**

**product\_id, product\_name, old\_status, new\_status**



SELECT

&#x20;   p\_y.product\_id,

&#x20;   p\_y.product\_name,

&#x20;   p\_y.status AS old\_status,

&#x20;   p\_t.status AS new\_status

FROM

&#x20;   products\_yesterday p\_y

JOIN

&#x20;   products\_today p\_t

ON

&#x20;   p\_y.product\_id = p\_t.product\_id

WHERE

&#x20;   p\_y.status <> p\_t.status;



**5. SQL Task 5 — Short Explanation**



**1. Why did you use INNER JOIN, LEFT JOIN, NOT EXISTS, or another approach?**



INNER JOIN is used when we only care about products that exist in both tables (e.g., price or status changes).



LEFT JOIN is used when we want all rows from one table and to check if they’re missing in the other (e.g., new products today or missing products from yesterday).



NOT EXISTS or IS NULL are alternative ways to detect absence. They achieve the same result as LEFT JOIN ... IS NULL, but the choice depends on readability and performance preferences.

&#x20;

**2. What would change if product\_id was not unique?**



If product\_id is not unique, joins could produce duplicate rows or incorrect comparisons.



Example: If the same product\_id appears twice in products\_today, the join with yesterday’s table would multiply results.



To fix this, we’d need to enforce uniqueness (primary key constraint) or use GROUP BY / DISTINCT to clean results.



**3. What issue could happen if price or status can be NULL?**



If price or status can be NULL, comparisons like p\_y.price <> p\_t.price or p\_y.status <> p\_t.status may fail because NULL is not equal to anything (even another NULL).



This could cause false negatives (changes not detected).



To handle it, we’d use functions like COALESCE or explicit IS NULL checks, e.g.:



WHERE COALESCE(p\_y.price, -1) <> COALESCE(p\_t.price, -1)



**PART - C**



**Prompt used:**

You are an API expert and need to genetate the API scripts for the given scenarios:



Assume there is an endpoint:

GET /api/orders/{order\_id}

Example successful response:

{

&#x20; "order\_id": "ORD-1001",

&#x20; "customer\_id": "C001",

&#x20; "amount": 100.50,

&#x20; "currency": "GBP",

&#x20; "status": "PAID",

&#x20; "created\_at": "2026-05-20T10:30:00Z"

}





**API Task 1 — Test Case Design**

**Write 5 test cases you would automate for this endpoint.**

**For each test case, include:**

**1. Test name**

**2. Input**

**3. Expected result**

**4. Why this test is useful**



Testcases available in Excel file



**API Task 2 — Simple Automated Test**



Write pseudo-code, or real code if you prefer, for one automated API test that validates:

GET /api/orders/ORD-1001 returns HTTP 200 and status = PAID

You may use any style you are comfortable with, for example:

Playwright API testing

RestAssured - **Preferred**

Python requests

Postman-style pseudo-code

Any other reasonable API testing approach









import io.restassured.RestAssured;

import io.restassured.response.Response;

import org.junit.jupiter.api.Test;



import static io.restassured.RestAssured.given;

import static org.hamcrest.Matchers.equalTo;



public class OrderApiTest {



&#x20;   @Test

&#x20;   public void testGetOrderReturnsPaidStatus() {

&#x20;       // Base URI setup

&#x20;       RestAssured.baseURI = "http://localhost:8080"; // Replace with actual host



&#x20;       // Perform GET request and validate response

&#x20;       given()

&#x20;           .when()

&#x20;               .get("/api/orders/ORD-1001")

&#x20;           .then()

&#x20;               .statusCode(200) // Validate HTTP 200

&#x20;               .body("status", equalTo("PAID")); // Validate status field

&#x20;   }

}











Candidate acknowledgement:

&#x20;

By submitting this exercise, I confirm that:

&#x20;

1\. I have followed the AI usage rules.

2\. If I used AI, I have included the full relevant AI transcript or equivalent usage record.

3\. I understand the submitted solution.

4\. I am able to explain, modify, and debug the solution during the interview.

5\. I understand that failure to disclose AI use, or inability to explain the submitted work, may result in rejection.

