**PART A - SQL Exercise:**



You are given two tables representing yesterday’s and today’s product data.



Table: products\_yesterday



**product\_id	product\_name	price	status**

1001		Coffee Mug	12.50	ACTIVE

1002		Laptop Stand	38.00	ACTIVE

1003		Wireless Mouse	19.99	ACTIVE

1004		Old Keyboard	29.99	DISCONTINUED

1005		Notebook	4.50	ACTIVE

1008		Desk Lamp	24.00	ACTIVE



Table: products\_today



**product\_id	product\_name	price	status**

1001		Coffee Mug	12.50	ACTIVE

1002		Laptop Stand	35.00	ACTIVE

1003		Wireless Mouse	21.99	ACTIVE

1005		Notebook	4.50	INACTIVE

1006		Webcam		59.00	ACTIVE

1007		USB Cable	7.99	ACTIVE

1008		Desk Lamp	24.00	ACTIVE



**SQL Task 1 — Price Changes**



Write a SQL query to find products whose price changed from yesterday to today.

Expected output columns:

product\_id, product\_name, old\_price, new\_price



**Answer:**



SELECT

&#x20;   t.product\_id,

&#x20;   t.product\_name,

&#x20;   y.price AS old\_price,

&#x20;   t.price AS new\_price

FROM products\_today t

JOIN products\_yesterday y

&#x20;   ON t.product\_id = y.product\_id

WHERE t.price <> y.price;

&#x20;

**SQL Task 2 — New Products**



Write a SQL query to find products that are new today, meaning they exist in products\_today but not in products\_yesterday.

Expected output columns:

product\_id, product\_name, price, status



**Answer:**



SELECT

&#x20;   t.product\_id,

&#x20;   t.product\_name,

&#x20;   t.price,

&#x20;   t.status

FROM products\_today t

LEFT JOIN products\_yesterday y

&#x20;   ON t.product\_id = y.product\_id

WHERE y.product\_id IS NULL;

&#x20;

**SQL Task 3 — Missing Products**



Write a SQL query to find products that existed yesterday but are missing today.

Expected output columns:

product\_id, product\_name, price, status



**Answer:**



SELECT

&#x20;   y.product\_id,

&#x20;   y.product\_name,

&#x20;   y.price,

&#x20;   y.status

FROM products\_yesterday y

WHERE NOT EXISTS (

&#x20;   SELECT 1

&#x20;   FROM products\_today t

&#x20;   WHERE t.product\_id = y.product\_id

);



**SQL Task 4 — Status Changes**



Write a SQL query to find products whose status changed from yesterday to today.

Expected output columns:

product\_id, product\_name, old\_status, new\_status



**Answer:**



SELECT

&#x20;   t.product\_id,

&#x20;   t.product\_name,

&#x20;   y.status AS old\_status,

&#x20;   t.status AS new\_status

FROM products\_yesterday y

INNER JOIN products\_today t

&#x20;   ON y.product\_id = t.product\_id

WHERE y.status <> t.status;



**SQL Task 5 — Short Explanation**



**1. Why did you use INNER JOIN, LEFT JOIN, NOT EXISTS, or another approach?**



Task 1 – Price Changes: I used INNER JOIN because I only need products that exist in both yesterday and today.

Task 2 – New Products: I used LEFT JOIN because I need products from today that have no matching record in yesterday.

Task 3 – Missing Products: I used NOT EXISTS because I need products from yesterday that have no matching record in today.

Task 4 – Status Changes: I used INNER JOIN because the product must exist in both tables to compare its status.



**2. What would change if product\_id was not unique?**



If product\_id is not unique, the joins can produce duplicate or incorrect combinations.

For example, if product 1001 appears twice in yesterday and twice in today, the join could produce 4 rows instead of one.



**3. What issue could happen if price or status can be NULL?**



In Task 1 I have used the where condition like,



**WHERE y.price <> t.price**



Sometimes it does not detect all NULL changes because SQL uses three-valued logic.\[True, False, Unknown]



For example:

y.price = 20.00 and t.price = NULL

then while evaluating this condition SQL gives the result as UNKNOWN

Similarly, if y.price = NULL and t.price = 20.00 then the result is UNKNOWN.



So to do the NULL-safe comparison, we need to explicitly handle NULLs like the following:



WHERE (y.price <> t.price)

&#x20;  OR (y.price IS NULL AND t.price IS NOT NULL)

&#x20;  OR (y.price IS NOT NULL AND t.price IS NULL);



The same approach can be used for status.



**Part C — Basic API Testing Thinking**



Assume there is an endpoint:



GET /api/orders/{order\_id}

Example successful response:

{

&#x20; "order\_id": "ORD-1001",

&#x20; "customer\_id": "C001",

&#x20; "amount": 100.50,

&#x20; "currency": "GBP",

&#x20; "status": "PAID",

&#x20; "created\_at": "2026-05-20T10:30:00Z"

}



**API Task 1 — Test Case Design**



Write 5 test cases you would automate for this endpoint.

For each test case, include:

1\. Test name

2\. Input

3\. Expected result

4\. Why this test is useful





&#x09;

|S.NO.|Test name|Input|Expected result|Why useful|
|-|-|-|-|-|
|1|Verify valid order returns details|order\_id = ORD-1001|HTTP 200. Response contains order\_id = ORD-1001, customer\_id = C001, amount = 100.50, currency = GBP, and status = PAID.|It validates the main happy path.|
|2|Verify non-existing order|order\_id = ORD-9999|HTTP 404 with an appropriate error message/body.|It ensures the API handles unknown orders correctly.|
|3|Verify invalid order ID format|order\_id = 1001|HTTP 400 with validation error message in JSON body|Checks input validation.|
|4|Verify response schema and data types|order\_id = ORD-1001|HTTP 200. order\_id, customer\_id, currency, status are strings; amount is numeric; created\_at is a valid ISO-8601 timestamp.|It detects contract/schema issues that functional checks may miss.|
|5|Verify special/empty order ID|input1: order\_id = "" input2: /api/orders/(no ID segment)|result1: HTTP 400 with validation error. <br />result2: HTTP 404 Not Found|It checks robustness against missing/invalid input.|





**API Task 2 — Simple Automated Test**



Write pseudo-code, or real code if you prefer, for one automated API test that validates:

GET /api/orders/ORD-1001 returns HTTP 200 and status = PAID

You may use any style you are comfortable with, for example:

Playwright API testing

RestAssured

Python requests

Postman-style pseudo-code

Any other reasonable API testing approach



**Pseudocode:**

import requests



def test\_get\_order\_status():

&#x20;   url = "http://example.com/api/orders/ORD-1001"

&#x20;   response = requests.get(url)



&#x20;   # Validate HTTP status code

&#x20;   assert response.status\_code == 200, f"Expected 200, got {response.status\_code}"



&#x20;   # Validate JSON response

&#x20;   data = response.json()

&#x20;   assert data\["status"] == "PAID", f"Expected status PAID, got {data\['status']}"



&#x20;   print("Test Passed: GET /api/orders/ORD-1001 returns 200 and status = PAID")



test\_get\_order\_status()



**I have attached the AI Transcript in this zip file.**



By submitting this exercise, I confirm that:

&#x20;

1\. I have followed the AI usage rules.

2\. If I used AI, I have included the full relevant AI transcript or equivalent usage record.

3\. I understand the submitted solution.

4\. I am able to explain, modify, and debug the solution during the interview.

5\. I understand that failure to disclose AI use, or inability to explain the submitted work, may result in rejection.

