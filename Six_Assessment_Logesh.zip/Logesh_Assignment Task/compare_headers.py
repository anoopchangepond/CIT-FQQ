import sys
import os


def read_headers(file_path):
    """Read and return headers from the first row of a CSV file."""
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"File does not exist: {file_path}")

    with open(file_path, "r", encoding="utf-8-sig", newline="") as file:
        first_line = file.readline()

    if not first_line.strip():
        raise ValueError(f"CSV file is empty: {file_path}")

    headers = [header.strip() for header in first_line.strip().split(",")]
    headers = [header for header in headers if header]

    if not headers:
        raise ValueError(f"Header row contains no valid headers: {file_path}")

    return headers


def compare_headers(expected_file, actual_file):
    expected = read_headers(expected_file)
    actual = read_headers(actual_file)

    expected_set = set(expected)
    actual_set = set(actual)

    only_expected = [h for h in expected if h not in actual_set]
    only_actual = [h for h in actual if h not in expected_set]
    common = [h for h in expected if h in actual_set]

    expected_common = [h for h in expected if h in actual_set]
    actual_common = [h for h in actual if h in expected_set]

    return {
        "only_expected": only_expected,
        "only_actual": only_actual,
        "common": common,
        "same_order": expected_common == actual_common,
    }


def main():
    if len(sys.argv) != 3:
        print("Usage: python compare_headers.py <expected.csv> <actual.csv>")
        sys.exit(1)

    expected_file = sys.argv[1]
    actual_file = sys.argv[2]

    try:
        result = compare_headers(expected_file, actual_file)

        print(f"\nOnly in {expected_file}:")
        for header in result["only_expected"]:
            print(header)

        print(f"\nOnly in {actual_file}:")
        for header in result["only_actual"]:
            print(header)

        print("\nCommon headers:")
        for header in result["common"]:
            print(header)

        print("\nCommon headers in same relative order:")
        print(result["same_order"])

    except (FileNotFoundError, ValueError) as error:
        print(f"ERROR: {error}")
        sys.exit(1)


if __name__ == "__main__":
    main()
