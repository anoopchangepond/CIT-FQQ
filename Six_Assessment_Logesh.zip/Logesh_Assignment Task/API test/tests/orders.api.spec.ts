import { test, expect } from '@playwright/test';

test('GET order should return correct order details', async ({ request }) => {
  const response = await request.get('/api/orders/ORD-1001');

  expect(response.status()).toBe(200);

  const body = await response.json();

  expect(body).toMatchObject({
    order_id: 'ORD-1001',
    customer_id: 'C001',
    amount: 100.50,
    currency: 'GBP',
    status: 'PAID',
  });

  expect(body.created_at).toBeTruthy();
});