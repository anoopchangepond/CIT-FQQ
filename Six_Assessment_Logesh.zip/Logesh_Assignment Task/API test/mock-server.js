const http = require('node:http');
const PORT = Number(process.env.PORT || 3000);
const orders = {
  'ORD-1001': {
    order_id: 'ORD-1001',
    customer_id: 'C001',
    amount: 100.50,
    currency: 'GBP',
    status: 'PAID',
    created_at: '2026-01-01T00:00:00.000Z'
  }
};

function sendJson(res, status, payload) {
  const body = JSON.stringify(payload);
  res.writeHead(status, {
    'Content-Type': 'application/json',
    'Content-Length': Buffer.byteLength(body)
  });
  res.end(res.req.method === 'HEAD' ? '' : body);
}

const server = http.createServer((req, res) => {
  const pathname = new URL(req.url || '/', 'http://localhost').pathname;

  if ((req.method === 'GET' || req.method === 'HEAD') && pathname === '/health') {
    return sendJson(res, 200, { status: 'ok' });
  }

  const match = pathname.match(/^\/api\/orders\/([^/]+)$/);
  if ((req.method === 'GET' || req.method === 'HEAD') && match) {
    const order = orders[decodeURIComponent(match[1])];
    return order
      ? sendJson(res, 200, order)
      : sendJson(res, 404, { error: 'Order not found' });
  }

  return sendJson(res, 404, { error: 'Not found' });
});

server.listen(PORT, () => {
  console.log(`Mock API listening on http://127.0.0.1:${PORT}`);
});

function shutdown() {
  server.close(() => process.exit(0));
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
