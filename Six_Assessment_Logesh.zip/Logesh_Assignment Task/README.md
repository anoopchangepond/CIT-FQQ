Language Used
SQL — for Part A (product data comparison queries).
Python 3 — for Part B (CSV header comparison tool and its tests).
TypeScript (Playwright) — for Part C (automated API test example).



Part A - SQL



answers.sql file contains all sql task



1. Why use INNER JOIN / LEFT JOIN?

   - INNER JOIN is used for Tasks 1 and 4 because we compare

     products that exist in both tables.

   - LEFT JOIN is used for Tasks 2 and 3 because we find

     products that exist in one table but not the other.

   - NOT EXISTS can also be used, but LEFT JOIN is simple and

     easy to understand.



2. What if product_id is not unique?

   The join could create duplicate or incorrect results because

   one product could match multiple rows.

   We would need to make each row unique first, for example

   using ROW_NUMBER(), or use additional columns in the join.



3. What if price or status can be NULL?

   Normal SQL comparisons do not treat NULL like a normal value.

   For example:

       NULL <> 10

   does not return TRUE.

   So a change from a value to NULL might not be detected.

   We should use IS DISTINCT FROM where supported, or add

   explicit NULL checks.



Part B - Python



CSV Header comparison

1. Make sure the following files are in the same folder:

   * compare_headers.py
   * expected_orders.csv
   * actual_orders.csv
   * test_compare_headers.py
2. Run from the command line:

```bash
   python compare_headers.py expected_orders.csv actual_orders.csv
   ```

Run tests

```bash
python test_compare_headers.py
```



Part C - API Test



1. Created 5 testcase which covers positive, negative and edge case scenario to automate the give end point
Testcase are written in api_testcases.xlsx file



2. API automated test
The API automation test validates the order API response for:
GET /api/orders/ORD-1001

The API automation is implemented using Playwright with a local mock server to ensure reliable and deterministic test execution.

Endpoint: GET /api/orders/ORD-1001
Tool: Playwright API testing
Mock server: Local Node.js server on 127.0.0.1:3000
Health check: /health
Validations: HTTP status, order ID, status, currency, amount, and response structure.
Playwright automatically starts the mock server before running tests.
No dependency on external or placeholder API hosts.
Run
cd "API test"
npm ci
npx playwright install
npm test

Manual mock-server check
npm run mock

open new terminal without interrupting mock server

Then:

curl http://127.0.0.1:3000/health

Expected:

{"status":"ok"}

then run
npm test


Result: The API test is self-contained, repeatable, and suitable for automated execution.


## AI Usage



I used ChatGPT to help review the SQL approach, CSV comparison logic,

test scenarios and error handling. The relevant AI conversation is

included in AI_TRANSCRIPT.md.



## Candidate acknowledgement



By submitting this exercise, I confirm that:



1. I have followed the AI usage rules.

2. If I used AI, I have included the full relevant AI transcript or equivalent usage record.

3. I understand the submitted solution.

4. I am able to explain, modify, and debug the solution during the interview.

5. I understand that failure to disclose AI use, or inability to explain the submitted work, may result in rejection.



