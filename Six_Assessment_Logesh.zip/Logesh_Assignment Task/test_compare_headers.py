import os
import tempfile

from compare_headers import compare_headers


def create_csv(content):
    file = tempfile.NamedTemporaryFile(
        mode="w",
        suffix=".csv",
        delete=False,
        encoding="utf-8",
        newline=""
    )
    file.write(content)
    file.close()
    return file.name


def test_identical_headers():
    file1 = create_csv("id,name,amount\n1,A,100\n")
    file2 = create_csv("id,name,amount\n2,B,200\n")

    result = compare_headers(file1, file2)

    assert result["only_expected"] == []
    assert result["only_actual"] == []
    assert result["common"] == ["id", "name", "amount"]
    assert result["same_order"] is True

    os.unlink(file1)
    os.unlink(file2)


def test_missing_header():
    file1 = create_csv("id,name,amount\n")
    file2 = create_csv("id,name\n")

    result = compare_headers(file1, file2)

    assert result["only_expected"] == ["amount"]
    assert result["only_actual"] == []
    assert result["common"] == ["id", "name"]

    os.unlink(file1)
    os.unlink(file2)


def test_headers_with_spaces():
    file1 = create_csv(" id , name , amount \n")
    file2 = create_csv("id,name,amount\n")

    result = compare_headers(file1, file2)

    assert result["only_expected"] == []
    assert result["only_actual"] == []
    assert result["common"] == ["id", "name", "amount"]
    assert result["same_order"] is True

    os.unlink(file1)
    os.unlink(file2)


def test_different_order():
    file1 = create_csv("id,name,amount\n")
    file2 = create_csv("amount,id,name\n")

    result = compare_headers(file1, file2)

    assert result["common"] == ["id", "name", "amount"]
    assert result["same_order"] is False

    os.unlink(file1)
    os.unlink(file2)


def test_windows_line_endings():
    file1 = create_csv("id,name,amount\r\n1,A,100\r\n")
    file2 = create_csv("id,name,amount\r\n2,B,200\r\n")

    result = compare_headers(file1, file2)

    assert result["common"] == ["id", "name", "amount"]
    assert result["same_order"] is True

    os.unlink(file1)
    os.unlink(file2)


if __name__ == "__main__":
    test_identical_headers()
    test_missing_header()
    test_headers_with_spaces()
    test_different_order()
    test_windows_line_endings()
    print("All tests passed!")
