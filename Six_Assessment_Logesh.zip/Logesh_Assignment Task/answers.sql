-- ============================================================
-- Part A — SQL Exercise
-- Product Data Comparison: products_yesterday vs products_today
-- ============================================================
CREATE TABLE products_yesterday (
    product_id INT PRIMARY KEY,
    product_name VARCHAR(100),
    price DECIMAL(10,2),
    status VARCHAR(20)
);
INSERT INTO products_yesterday
(product_id, product_name, price, status)
VALUES
(1001, 'Coffee Mug', 12.50, 'ACTIVE'),
(1002, 'Laptop Stand', 38.00, 'ACTIVE'),
(1003, 'Wireless Mouse', 19.99, 'ACTIVE'),
(1004, 'Old Keyboard', 29.99, 'DISCONTINUED'),
(1005, 'Notebook', 4.50, 'ACTIVE'),
(1008, 'Desk Lamp', 24.00, 'ACTIVE');

CREATE TABLE products_today (
    product_id INT PRIMARY KEY,
    product_name VARCHAR(100),
    price DECIMAL(10,2),
    status VARCHAR(20)
);

INSERT INTO products_today
(product_id, product_name, price, status)
VALUES
(1001, 'Coffee Mug', 12.50, 'ACTIVE'),
(1002, 'Laptop Stand', 35.00, 'ACTIVE'),
(1003, 'Wireless Mouse', 21.99, 'ACTIVE'),
(1005, 'Notebook', 4.50, 'INACTIVE'),
(1006, 'Webcam', 59.00, 'ACTIVE'),
(1007, 'USB Cable', 7.99, 'ACTIVE'),
(1008, 'Desk Lamp', 24.00, 'ACTIVE');

-- ------------------------------------------------------------
-- SQL Task 1 — Price Changes
-- Find products whose price changed from yesterday to today.
-- ------------------------------------------------------------
SELECT 
    y.product_id,
    y.product_name,
    y.price AS old_price,
    t.price AS new_price
FROM products_yesterday y
INNER JOIN products_today t 
    ON y.product_id = t.product_id
WHERE y.price <> t.price;


-- ------------------------------------------------------------
-- SQL Task 2 — New Products
-- Find products that exist in products_today but not in
-- products_yesterday.
-- ------------------------------------------------------------
SELECT 
    t.product_id,
    t.product_name,
    t.price,
    t.status
FROM products_today t
LEFT JOIN products_yesterday y 
    ON t.product_id = y.product_id
WHERE y.product_id IS NULL;


-- ------------------------------------------------------------
-- SQL Task 3 — Missing Products
-- Find products that existed yesterday but are missing today.
-- ------------------------------------------------------------
SELECT 
    y.product_id,
    y.product_name,
    y.price,
    y.status
FROM products_yesterday y
LEFT JOIN products_today t 
    ON y.product_id = t.product_id
WHERE t.product_id IS NULL;


-- ------------------------------------------------------------
-- SQL Task 4 — Status Changes
-- Find products whose status changed from yesterday to today.
-- ------------------------------------------------------------
SELECT 
    y.product_id,
    y.product_name,
    y.status AS old_status,
    t.status AS new_status
FROM products_yesterday y
INNER JOIN products_today t 
    ON y.product_id = t.product_id
WHERE y.status <> t.status;


-- ============================================================
-- SQL Task 5 — Short Explanation (README notes)
-- ============================================================
--
-- 1. Why use INNER JOIN / LEFT JOIN?
--    - INNER JOIN is used for Tasks 1 and 4 because we compare
--      products that exist in both tables.
--    - LEFT JOIN is used for Tasks 2 and 3 because we find
--      products that exist in one table but not the other.
--    - NOT EXISTS can also be used, but LEFT JOIN is simple and
--      easy to understand.
--
-- 2. What if product_id is not unique?
--    The join could create duplicate or incorrect results because
--    one product could match multiple rows.
--    We would need to make each row unique first, for example
--    using ROW_NUMBER(), or use additional columns in the join.
--
-- 3. What if price or status can be NULL?
--    Normal SQL comparisons do not treat NULL like a normal value.
--    For example:
--
--        NULL <> 10
--
--    does not return TRUE.
--    So a change from a value to NULL might not be detected.
--    We should use IS DISTINCT FROM where supported, or add
--    explicit NULL checks.
